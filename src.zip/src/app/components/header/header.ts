/* src/app/components/header/header.component.ts */
import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [],
  templateUrl: './header.html',
  styleUrl: './header.css'
})
export class HeaderComponent {
  // This component can have properties and methods for header logic,
  // like user profile information or global search functionality.
}
