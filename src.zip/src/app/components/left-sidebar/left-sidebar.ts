import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-left-sidebar',
  standalone: true,
  // Import RouterLink and RouterLinkActive to enable navigation
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './left-sidebar.html',
  styleUrl: './left-sidebar.css'
})
export class LeftSidebarComponent {
  // This component is currently presentational but could hold
  // logic for dynamically generating navigation links in the future.
}
