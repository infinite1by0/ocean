import { Component } from '@angular/core';

@Component({
  selector: 'app-install',
  standalone: true,
  imports: [],
  templateUrl: './install.html',
  styleUrl: './install.css'
})
export class InstallComponent {
  // Logic for the install page goes here.
}