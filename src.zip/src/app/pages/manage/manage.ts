import { Component } from '@angular/core';

@Component({
  selector: 'app-manage',
  standalone: true,
  imports: [],
  templateUrl: './manage.html',
  styleUrl: './manage.css'
})
export class ManageComponent {
  // Logic for the manage page goes here.
}