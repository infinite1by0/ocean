import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header';
import { LeftSidebarComponent } from './components/left-sidebar/left-sidebar';
import { RightSidebarComponent } from './components/right-sidebar/right-sidebar';

@Component({
  selector: 'app-root',
  standalone: true,
  // Import all the layout components and the RouterOutlet
  imports: [
    RouterOutlet,
    HeaderComponent,
    LeftSidebarComponent,
    RightSidebarComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  title = 'dashboard-app';
}
