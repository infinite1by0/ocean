// This interface defines the data structure for a single service.
// Using an interface provides type safety and autocompletion in your IDE.

export interface ServiceStatus {
    id: string;
    name: string;
    version: string;
    isRunning: boolean;
    lastUpdated: string; // ISO date string from the API
}
