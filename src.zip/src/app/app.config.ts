import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';

import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }), 
    
    // Makes the defined routes available to the application
    provideRouter(routes),

    // Registers the HttpClient service so we can make API calls
    provideHttpClient()
  ]
};
