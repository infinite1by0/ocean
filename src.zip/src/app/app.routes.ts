import { Routes } from '@angular/router';
import { InstallComponent } from './pages/install/install';
import { ManageComponent } from './pages/manage/manage';

export const routes: Routes = [
    // Route for the "Install" page
    {
        path: 'install',
        component: InstallComponent,
        title: 'Dashboard | Install' // Sets the browser tab title
    },
    // Route for the "Manage" page
    {
        path: 'manage',
        component: ManageComponent,
        title: 'Dashboard | Manage'
    },
    // Default route: redirects to '/install' if the path is empty
    {
        path: '',
        redirectTo: '/install',
        pathMatch: 'full'
    },
    // Wildcard route for 404 Not Found pages (optional but recommended)
    {
        path: '**',
        redirectTo: '/install'
    }
];
