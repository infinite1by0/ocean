import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { ServiceStatus } from '../models/service-status';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  // A mock API endpoint. Replace this with your actual API URL.
  private apiUrl = '/api/services';

  constructor(private http: HttpClient) { }

  /**
   * Fetches the status of all services.
   * In a real app, this would make an HTTP GET request.
   * For this example, we return mock data using `of()`.
   */
  getServiceStatuses(): Observable<ServiceStatus[]> {
    // In a real application, you would use:
    // return this.http.get<ServiceStatus[]>(this.apiUrl);

    // Returning mock data for demonstration purposes.
    const mockServices: ServiceStatus[] = [
      { id: 'srv1', name: 'Authentication Service', version: '2.1.0', isRunning: true, lastUpdated: new Date().toISOString() },
      { id: 'srv2', name: 'Data Processor', version: '1.8.3', isRunning: true, lastUpdated: new Date(Date.now() - 3600000).toISOString() },
      { id: 'srv3', name: 'Notification Queue', version: '3.0.0', isRunning: false, lastUpdated: new Date(Date.now() - 86400000).toISOString() },
    ];

    return of(mockServices);
  }
}
